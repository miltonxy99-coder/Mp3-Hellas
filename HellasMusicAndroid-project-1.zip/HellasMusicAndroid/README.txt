HELLAS MUSIC — projeto Android

Este ZIP contém o código-fonte de um pequeno leitor de música com tema grego.
Não é ainda um ficheiro APK instalável.

Como gerar o APK:
1. Instala o Android Studio num computador.
2. Abre a pasta HellasMusicAndroid no Android Studio.
3. Aguarda a sincronização do Gradle.
4. Escolhe Build > Build APK(s).
5. O APK de teste é criado em app/build/outputs/apk/debug/.

Nota: o projeto usa um WebView e HTML local. Para um APK de distribuição final, gera uma versão assinada no Android Studio.
